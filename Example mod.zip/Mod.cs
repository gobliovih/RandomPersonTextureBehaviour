using UnityEngine;

namespace Mod
{
    public class Mod
    {
        public static void Main()
        {
            ModAPI.Register(
            new Modification()
            {
                OriginalItem = ModAPI.FindSpawnable("Human"),
                NameOverride = "Cool human",
                DescriptionOverride = "This is a cool human",
                CategoryOverride = ModAPI.FindCategory("Entities"),
                ThumbnailOverride = ModAPI.LoadSprite("cool texture_skin.png"),
                AfterSpawn = (Instance) =>
                {
                    var rptb = Instance.AddComponent<RandomPersonTextureBehaviour>();

                    rptb.AddSkin("cool skin"); // you can also add a scale and path to  in method parametrs (Ex: "cool skin", 1, "textures/").
                    rptb.AddSkin("also cool skin");
                }
            });
        }
    }
}